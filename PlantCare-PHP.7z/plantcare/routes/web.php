<?php

use App\Http\Controllers\HomeController;
use App\Http\Controllers\PlantsController;
use App\Http\Controllers\SpeciesController;
use App\Http\Controllers\TagsController;
use App\Http\Controllers\TaskTypesController;
use App\Http\Controllers\ApiController;
use App\Http\Controllers\UserController;
use Illuminate\Support\Facades\Route;

Route::get('/', HomeController::class);

//-----------------------------------API-----------------------------------
Route::get('/api/plants', [ApiController::class, 'getPlants']);

//-----------------------------------PLANTS-----------------------------------
Route::get('/plants', [PlantsController::class,"index"]);

Route::get('/plants/edit/{id}',[PlantsController::class,"edit"]);

Route::post('/plants/edit/{id}',[PlantsController::class,"update"]);

Route::get('/plants/delete/{id}',[PlantsController::class,"delete"]);

Route::get('/plants/create-new',[PlantsController::class,"createNew"]);

Route::post('/plants/create-new',[PlantsController::class,"addToDb"]);

Route::get('/plants/plant-details/{id}',[PlantsController::class,"plantDetails"]);


Route::post('/plants/update-watering/{id}',[PlantsController::class,"updateLastWateringDate"])->name('plant.updateLastWateringDate');


Route::get('/plants/add-tag/{id}',[PlantsController::class,"addTag"])->name('plant.addTag');

Route::post('/plants/add-tag/{id}',[PlantsController::class,"addTagToDb"]);

Route::get('/plants/delete-tag/{id}',[PlantsController::class,"deleteTag"])->name('plant.deleteTag');


Route::post('/plants/complete-task/{id}',[PlantsController::class,"markTaskAsCompleted"])->name('plant.markTaskCompleted');

Route::get('/plants/add-task/{id}',[PlantsController::class,"addTask"])->name('plant.addTask');

Route::post('/plants/add-task/{id}',[PlantsController::class,"addTaskToDb"]);

Route::get('/plants/delete-task/{id}',[PlantsController::class,"deleteTask"])->name('plant.deleteTask');;


Route::get('/plants/add-note/{id}',[PlantsController::class,"addNote"])->name('plant.addNote');

Route::post('/plants/add-note/{id}',[PlantsController::class,"addNoteToDb"]);

Route::get('/plants/delete-note/{id}',[PlantsController::class,"deleteNote"])->name('plant.deleteNote');;


//-----------------------------------TAGS-----------------------------------
Route::get('/tags', [TagsController::class,"index"]);

Route::get('/tags/edit/{id}',[TagsController::class,"edit"]);

Route::post('/tags/edit/{id}',[TagsController::class,"update"]);

Route::get('/tags/delete/{id}',[TagsController::class,"delete"]);

Route::get('/tags/create-new',[TagsController::class,"createNew"]);

Route::post('/tags/create-new',[TagsController::class,"addToDb"]);

Route::get('/tags/plants/{id}',[TagsController::class,"seePlants"]);


//-----------------------------------SPECIES-----------------------------------
Route::get('/species', [SpeciesController::class,"index"]);

Route::get('/species/edit/{id}',[SpeciesController::class,"edit"]);

Route::post('/species/edit/{id}',[SpeciesController::class,"update"]);

Route::get('/species/delete/{id}',[SpeciesController::class,"delete"]);

Route::get('/species/create-new',[SpeciesController::class,"createNew"]);

Route::post('/species/create-new',[SpeciesController::class,"addToDb"]);

Route::get('/species/plants/{id}',[SpeciesController::class,"seePlants"]);


//-----------------------------------TASK TYPES-----------------------------------
Route::get('/care-tasks', [TaskTypesController::class,"index"]);

Route::get('/care-tasks/edit/{id}',[TaskTypesController::class,"edit"]);

Route::post('/care-tasks/edit/{id}',[TaskTypesController::class,"update"]);

Route::get('/care-tasks/delete/{id}',[TaskTypesController::class,"delete"]);

Route::get('/care-tasks/create-new',[TaskTypesController::class,"createNew"]);

Route::post('/care-tasks/create-new',[TaskTypesController::class,"addToDb"]);

Route::get('/care-tasks/plants/{id}',[TaskTypesController::class,"seePlants"]);
