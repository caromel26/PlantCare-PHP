

<?php $__env->startSection("topMenu"); ?>
<a class="btn btn-primary" href="/plants">Back to Plants</a>
<?php $__env->stopSection(); ?>

<?php $__env->startSection("content"); ?>
<div class="container">
    <div class="row mb-3">
        <div class="col-sm-12 d-flex justify-content-between align-items-center">
            <h1 class="mb-0"><?php echo e($model->Name); ?></h1>
            <!-- <a class="btn btn-primary" href="{plants/edit/<?php echo e($model->Id); ?>">Edit Plant</a> -->
        </div>
    </div>
    <div class="row gy-3 mb-3">
    <div class="col-sm-12 col-md-6 col-lg-3">
        <div class="card">
            <div class="card-body">
                <b class="d-block mb-2">SPECIES</b>
                <p><?php echo e($model->Species->Name); ?></p>
            </div>
        </div>
    </div>
    <div class="col-sm-12 col-md-6 col-lg-3">
        <div class="card">
            <div class="card-body">
                <b class="d-block mb-2">WATERING FREQUENCY</b>
                <p><?php echo e($model->WateringFrequency); ?></p>
            </div>
        </div>
    </div>
    <div class="col-sm-12 col-md-6 col-lg-3">
        <div class="card">
            <div class="card-body">
                <b class="d-block mb-2">SUNLIGHT REQUIREMENTS</b>
                <p><?php echo e($model->SunlightRequirements); ?></p>
            </div>
        </div>
    </div>
    <div class="col-sm-12 col-md-6 col-lg-3">
    <div class="card">
    <div class="card-body d-flex justify-content-between align-items-center">
        <div>
            <b class="d-block mb-2">LAST WATERING DATE</b>
            <p><?php echo e(date('F j, Y', strtotime($model->LastWateringDate))); ?></p>
        </div>
        <form action="<?php echo e(route('plant.updateLastWateringDate', ['id' => $model->Id])); ?>" method="POST" style="display:inline;">
            <?php echo csrf_field(); ?>
            <button type="submit" class="btn btn-sm btn-info">Update</button>
        </form>
    </div>
</div>

</div>

</div>

    <div class="row gy-3">
        <!-- Tasks Column -->
        <div class="col-sm-12 col-md-4">
            <div class="card">
                <div class="card-body">
                    <b class="d-block mb-3">TASKS</b>
                    <ul class="nav nav-tabs" id="taskTabs" role="tablist">
                        <li class="nav-item">
                            <a class="nav-link active" id="uncompleted-tab" data-toggle="tab" href="#uncompleted" role="tab" aria-controls="uncompleted" aria-selected="true">Uncompleted</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" id="completed-tab" data-toggle="tab" href="#completed" role="tab" aria-controls="completed" aria-selected="false">Completed</a>
                        </li>
                    </ul>
                    <div class="tab-content" id="taskTabsContent">
                        <!-- Uncompleted Tasks Tab -->
                        <div class="tab-pane fade show active" id="uncompleted" role="tabpanel" aria-labelledby="uncompleted-tab">
                            <?php $__currentLoopData = $model->PlantCareTasks->where("IsActive", "=", true)->where("CompletionStatus", "=", false); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $task): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="task-item mb-3">
                                    <b><?php echo e($task->TaskType->Name); ?></b><br>
                                    <?php echo e($task->TaskType->Description); ?><br>
                                    <?php if($task->DueDate): ?>
                                        <?php
                                            $dueDate = strtotime($task->DueDate);
                                            $today = strtotime(date('Y-m-d'));
                                            $dateColorClass = '';
                                            if ($dueDate == $today) {
                                                $dateColorClass = 'text-warning';
                                            } elseif ($dueDate < $today) {
                                                $dateColorClass = 'text-danger';
                                            }
                                        ?>
                                        <span class="<?php echo e($dateColorClass); ?>">Due Date: <?php echo e(date('Y-m-d', $dueDate)); ?></span><br>
                                    <?php endif; ?>
                                    <form action="<?php echo e(route('plant.markTaskCompleted', ['id' => $task->Id])); ?>" method="POST" style="display:inline;">
                                        <?php echo csrf_field(); ?>
                                        <button type="submit" class="btn btn-sm btn-success mt-2">Mark as Completed</button>
                                    </form>
                                    <a class="btn btn-sm btn-danger mt-2" href="<?php echo e(route('plant.deleteTask', ['id' => $task->Id])); ?>">Delete</a>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <div id="addTaskForm" style="display: none;">
                                <form action="<?php echo e(route('plant.addTask', ['id' => $model->Id])); ?>" method="POST">
                                    <?php echo csrf_field(); ?>
                                    <select name="TaskTypeId" id="taskType" class="form-control">
                                        <?php $__currentLoopData = $allTasks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $task): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($task->Id); ?>"><?php echo e($task->Name); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                    <input type="date" name="DueDate" id="DueDate" class="form-control" value="<?php echo e(date('Y-m-d')); ?>" min="<?php echo e(date('Y-m-d')); ?>" placeholder="Due Date">
                                    <button type="submit" class="btn btn-success mt-2" id="saveTaskBtn">Save</button>
                                    <button type="button" class="btn btn-danger mt-2" id="cancelTaskBtn">Cancel</button>
                                </form>
                            </div>
                            <a class="btn btn-primary mt-2" href="#" id="addTaskBtn">Add Task</a>
                        </div>
                        <!-- Completed Tasks Tab -->
                        <div class="tab-pane fade" id="completed" role="tabpanel" aria-labelledby="completed-tab">
                            <?php $__currentLoopData = $model->PlantCareTasks->where("CompletionStatus", "=", true); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $task): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="task-item mb-3">
                                    <b class="text-success"><?php echo e($task->TaskType->Name); ?></b><br>
                                    <span class="text-success"><?php echo e($task->TaskType->Description); ?></span><br>
                                    <?php if($task->DueDate): ?>
                                    <span class="text-muted">Due Date: <?php echo e(date('Y-m-d', strtotime($task->DueDate))); ?></span><br>
                                    <?php endif; ?>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <script>
            document.addEventListener("DOMContentLoaded", function() {
                document.getElementById("addTaskBtn").addEventListener("click", function(event) {
                    event.preventDefault();
                    document.getElementById("addTaskForm").style.display = "block";
                });

                document.getElementById("cancelTaskBtn").addEventListener("click", function(event) {
                    event.preventDefault();
                    document.getElementById("addTaskForm").style.display = "none";
                });
            });
        </script>

    <!-- Notes Column -->
    <div class="col-sm-12 col-md-4">
        <div class="card">
            <div class="card-body">
                <b class="d-block mb-3">NOTES</b>
                <?php $__currentLoopData = $model->Notes->where("IsActive", "=", true); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $note): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <p>
                        <?php echo e($note->NoteText); ?><br>
                        <a class="btn btn-sm btn-danger" href="<?php echo e(route('plant.deleteNote', ['id' => $note->Id])); ?>">Delete</a>
                    </p><br>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <button class="btn btn-primary mt-2" id="addNoteBtn">Add Note</button>
                <form id="addNoteForm" style="display: none;" action="<?php echo e(route('plant.addNote', ['id' => $model->Id])); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <textarea class="form-control validate rounded-0" name="NoteText" id="NoteText" rows="3" placeholder="Enter your note"><?php echo e($model->NoteText); ?></textarea>
                    <div class="mt-2">
                        <button type="submit" class="btn btn-success">Save</button>
                        <button type="button" class="btn btn-danger ml-2" id="cancelAddNoteBtn">Cancel</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <script>
        document.addEventListener("DOMContentLoaded", function() {
            document.getElementById("addNoteBtn").addEventListener("click", function(event) {
                event.preventDefault();
                document.getElementById("addNoteForm").style.display = "block";
            });

            document.getElementById("cancelAddNoteBtn").addEventListener("click", function(event) {
                event.preventDefault();
                document.getElementById("addNoteForm").style.display = "none";
            });
        });
    </script>

        <!-- Tags Column -->
        <div class="col-sm-12 col-md-4">
            <div class="card">
                <div class="card-body">
                <b class="d-block mb-3">TAGS</b>
                    <div class="tag-container">
                        <?php $tagCount = 0; ?>
                        <?php $__currentLoopData = $model->PlantTags->where("IsActive", "=", true); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($tagCount % 3 == 0): ?>
                                <div class="tag-row">
                            <?php endif; ?>
                            <span class="badge badge-secondary bg-warning text-black">
                                <?php echo e($tag->Tag->Name); ?>

                                <a href="<?php echo e(route('plant.deleteTag', ['id' => $tag->Id])); ?>" class="material-icons font-xs text-danger cursor-pointer text-decoration-none">close</a>
                            </span>
                            <?php $tagCount++; ?>
                            <?php if($tagCount % 3 == 0): ?>
                                </div>
                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php if($tagCount % 3 != 0): ?>
                            </div>
                        <?php endif; ?>
                    </div>
                    <div id="addTagForm" style="display: none;">
                        <form action="<?php echo e(route('plant.addTag', ['id' => $model->Id])); ?>" method="POST">
                            <?php echo csrf_field(); ?>
                            <select name="TagId" id="TagId" class="form-control">
                            <?php $__currentLoopData = $allTags; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php
                                    $existingTag = $model->PlantTags->where('TagId', $tag->Id)->first();
                                ?>
                                <?php if((!$existingTag || $existingTag->IsActive==0) && $tag->IsActive): ?>
                                    <option value="<?php echo e($tag->Id); ?>"><?php echo e($tag->Name); ?></option>
                                <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                            <button type="submit" class="btn btn-success mt-2" id="saveTagBtn">Save</button>
                            <button type="button" class="btn btn-danger mt-2" id="cancelTagBtn">Cancel</button>
                        </form>
                    </div>
                    <a class="btn btn-primary mt-2" href="#" id="addTagBtn">Add Tag</a>
                </div>
            </div>
        </div>
        <script>
            document.addEventListener("DOMContentLoaded", function() {
                document.getElementById("addTagBtn").addEventListener("click", function(event) {
                    event.preventDefault();
                    document.getElementById("addTagForm").style.display = "block";
                });

                document.getElementById("cancelTagBtn").addEventListener("click", function(event) {
                    event.preventDefault();
                    document.getElementById("addTagForm").style.display = "none";
                });
            });
        </script>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make("main", ["pageTitle" => "Plant Details"], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\tools\xampp\htdocs\plantcare\resources\views/plants/plantDetails.blade.php ENDPATH**/ ?>