

<?php $__env->startSection("topMenu"); ?>
<a class="btn btn-primary" href="<?php echo e(url()->current()); ?>/create-new">Create new</a>
<?php $__env->stopSection(); ?>

<?php $__env->startSection("content"); ?>
<div class="container">
    <div class="row gy-4">
        <?php $__currentLoopData = $models; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="col-sm-12 col-md-6 col-lg-4">
            <div class="card border-success shadow">
                <div class="card-body">
                    <h5 class="card-title"><?php echo e($item->Name); ?></h5>
                    <hr>
                    <p class="card-text">
                        <?php $__currentLoopData = $item->PlantTags->where("IsActive", "=", true); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <span class="badge badge-secondary bg-warning text-black"><?php echo e($tag->Tag->Name); ?>

                                <a href="<?php echo e(url()->current()); ?>/delete-tag/<?php echo e($tag->Id); ?>" class="material-icons font-xs text-danger cursor-pointer text-decoration-none">close</a>
                            </span>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </p>
                </div>
                <div class="card-footer">
                    <div class="btn-group" role="group">
                        <a class="btn btn-primary" href="<?php echo e(url()->current()); ?>/edit/<?php echo e($item->Id); ?>">Edit</a>
                        <a class="btn btn-danger" href="<?php echo e(url()->current()); ?>/delete/<?php echo e($item->Id); ?>">Delete</a>
                        <a class="btn btn-success" href="<?php echo e(url()->current()); ?>/plant-details/<?php echo e($item->Id); ?>">Details</a>
                    </div>
                </div>
            </div>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make("main", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\tools\xampp\htdocs\plantcare\resources\views/plants/index.blade.php ENDPATH**/ ?>