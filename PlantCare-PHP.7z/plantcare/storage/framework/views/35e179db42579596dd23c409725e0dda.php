

<?php $__env->startSection("topMenu"); ?>
<a class="btn btn-primary" href="/plants">Back to Plants</a>
<?php $__env->stopSection(); ?>

<?php $__env->startSection("content"); ?>
<div class="container">
    <form method="POST" action="/plants/create-new">
        <?php echo csrf_field(); ?>
        <div class="row gy-3">
            <div class="col-md-12 col-lg-6 col-xxl-4">
                <div class="form-group">
                    <label for="Name" class="form-label">
                        <i class="material-icons-round align-middle">label</i>
                        Name
                    </label>
                    <input type="text" class="form-control validate" id="Name" name="Name" value="<?php echo e(old('Name')); ?>" required>
                </div>
            </div>
            
            <div class="col-md-12 col-lg-6 col-xxl-4">
                <div class="form-group">
                    <label for="Species" class="form-label">
                        <i class="material-icons-round align-middle">category</i>
                        Species
                    </label>
                    <select class="form-control validate" id="SpeciesId" name="SpeciesId" required>
                        <option value="" disabled selected>Select a species</option>
                        <?php $__currentLoopData = $speciesList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $species): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($species->Id); ?>"><?php echo e($species->Name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
            </div>

            <div class="col-md-12 col-lg-6 col-xxl-4">
                <div class="form-group">
                    <label for="WateringFrequency" class="form-label">
                        <i class="material-icons-round align-middle">opacity</i>
                        Watering Frequency
                    </label>
                    <input type="text" class="form-control validate" id="WateringFrequency" name="WateringFrequency" value="<?php echo e(old('WateringFrequency')); ?>" required>
                </div>
            </div>

            <div class="col-md-12 col-lg-6 col-xxl-4">
                <div class="form-group">
                    <label for="SunlightRequirements" class="form-label">
                        <i class="material-icons-round align-middle">wb_sunny</i>
                        Sunlight Requirements
                    </label>
                    <input type="text" class="form-control validate" id="SunlightRequirements" name="SunlightRequirements" value="<?php echo e(old('SunlightRequirements')); ?>" required>
                </div>
            </div>
            
            <div class="col-md-12 col-lg-6 col-xxl-4">
                <div class="form-group">
                    <label for="LastWateringDate" class="form-label">
                        <i class="material-icons-round palette-accent-text-color align-middle">today</i>
                        Last Watering Date
                    </label>
                    <input type="date" class="form-control validate" id="LastWateringDate" name="LastWateringDate" value="<?php echo e(old('LastWateringDate', date('Y-m-d'))); ?>" required>
                </div>
            </div>
            
            <div class="col-12">
                <button type="submit" class="btn btn-primary">Create</button>
            </div>
        </div>
    </form>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make("main", ["pageTitle" => "Plants - Create New"], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\tools\xampp\htdocs\plantcare\resources\views/plants/createNew.blade.php ENDPATH**/ ?>