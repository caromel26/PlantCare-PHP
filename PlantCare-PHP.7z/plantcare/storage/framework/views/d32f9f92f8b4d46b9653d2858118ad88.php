

<?php $__env->startSection("content"); ?>
<div class="container">
    <form method="GET" action="/api/plants">
        <div class="row gy-3">
            <div class="col-md-12">
                <div class="input-group">
                    <input type="text" class="form-control" name="query" placeholder="Search for plants...">
                    <button class="btn btn-primary" type="submit">Search</button>
                </div>
            </div>
        </div>
    </form>
    
    <div class="row gy-4 mt-4">
        <?php if(isset($plants)): ?>
            <?php $__currentLoopData = $plants; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $plant): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-md-6 col-lg-4">
                    <div class="card">
                        <div class="d-flex">
                            <img src="<?php echo e($plant['image_url'] ?? 'placeholder.jpg'); ?>" class="card-img-top img-fluid" style="width: 150px; height: 150px; object-fit: cover;" alt="Plant Image">
                            <div class="card-body">
                                <h5 class="card-title"><?php echo e($plant['common_name']); ?></h5>
                                <p class="card-text"><b>Scientific Name:</b> <?php echo e($plant['scientific_name']); ?></p>
                                <p class="card-text"><b>Family:</b> <?php echo e($plant['family']); ?></p>
                                <p class="card-text"><b>Genus:</b> <?php echo e($plant['genus']); ?></p>
                                <p class="card-text"><b>Family Common Name:</b> <?php echo e($plant['family_common_name']); ?></p>
                                <!-- Add more information as needed -->
                            </div>
                        </div>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php elseif(isset($error)): ?>
            <div class="alert alert-danger"><?php echo e($error); ?></div>
        <?php else: ?>
            <p>No plants found. Try searching for something else.</p>
        <?php endif; ?>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make("main", ["pageTitle" => "API Plant Search"], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\tools\xampp\htdocs\plantcare\resources\views/api/index.blade.php ENDPATH**/ ?>