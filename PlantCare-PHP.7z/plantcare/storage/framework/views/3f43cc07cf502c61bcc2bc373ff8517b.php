

<?php $__env->startSection("content"); ?>
<div class="container">
    <div class="row">
        <div class="col-md-6">
            <h2><?php echo e($model->TaskType->Name); ?></h2>
            <p><?php echo e($model->TaskType->Description); ?></p>
        </div>
    </div>
    <div class="row">
        <div class="col-md-6">
            <h3>Assigned Plants</h3>
            <ul>
                <?php $__currentLoopData = $model->assignedPlants; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $plant): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($plant->Name); ?> <input type="checkbox" <?php echo e($plant->pivot->completionStatus ? 'checked' : ''); ?>> Completed</li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make("main", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\tools\xampp\htdocs\plantcare\resources\views/plantCareTasks/taskDetails.blade.php ENDPATH**/ ?>