

<?php $__env->startSection("topMenu"); ?>
<a class="btn btn-primary" href="/plant-care-tasks">All</a>
<?php $__env->stopSection(); ?>

<?php $__env->startSection("content"); ?>
<div class="container">
    <form method="POST" action="/plant-care-tasks/create-new">
        <?php echo csrf_field(); ?>
        <div class="row gy-3 mb-3">
            <div class="col-md-12 col-lg-6 col-xxl-4">
                <div class="input-group">
                    <label class="input-group-text">
                        <i class="material-icons-round align-middle">label</i>
                        Name
                    </label>
                    <input class="form-control validate" value="<?php echo e($model->TaskType->Name); ?>" name="Name">
                </div>
            </div>
        </div>
        <div class="row gy-3 mb-3">
            <div class="col-md-12 col-lg-6 col-xxl-4">
                <div class="input-group">
                    <label class="input-group-text w-100">
                        <i class="material-icons-round align-middle">notes</i>
                        Description
                    </label>
                    <textarea class="form-control validate rounded-0" rows="5" name="Description"><?php echo e($model->TaskType->Description); ?></textarea>
                </div>
            </div>
        </div>
        <div class="row gy-3">
            <div class="col-sm-12">
                <button class="btn btn-primary">Create</button>
            </div>
        </div>
    </form>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make("main",["pageTitle"=>"Care Tasks - Create New"], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\tools\xampp\htdocs\plantcare\resources\views/plantCareTasks/createNew.blade.php ENDPATH**/ ?>