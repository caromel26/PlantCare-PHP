

<?php $__env->startSection('topMenu'); ?>
<a class="btn btn-primary" href="<?php echo e(url('/care-tasks')); ?>">Back to Tasks</a>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="container">
    <h1 class="my-4">Plants in need of <?php echo e($task->Name); ?></h1>
    <div class="row gy-4">
        <?php $__currentLoopData = $plants; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $plant): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="col-sm-12 col-md-6 col-lg-3">
            <div class="card border-success shadow">
                <div class="card-body">
                    <h5 class="card-title"><?php echo e($plant->Name); ?></h5>
                    <p>Watering Frequency: <?php echo e($plant->WateringFrequency); ?></p>
                    <p>Sunlight Requirements: <?php echo e($plant->SunlightRequirements); ?></p>
                    <p>Last Watering Date: <?php echo e($plant->LastWateringDate); ?></p>
                </div>
            </div>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('main', ["pageTitle" => "Plants in need of " . $task->Name], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\tools\xampp\htdocs\plantcare\resources\views/careTasks/plants.blade.php ENDPATH**/ ?>