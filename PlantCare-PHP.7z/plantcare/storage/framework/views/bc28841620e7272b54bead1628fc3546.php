
<?php $__env->startSection("content"); ?>

<div class="container">
    <div class="row my-4">
        <div class="col-sm-12 text-center">
            <h1 class="display-4">Welcome to Your Plant Management Dashboard</h1>
            <p class="lead">Manage your plants, care tasks, species, and tags all in one place.</p>
        </div>
    </div>
    <div class="row gy-4">
        <div class="col-sm-6 col-md-3">
            <a href="/plants" class="text-decoration-none">
                <div class="card bg-success text-center shadow-sm h-100">
                    <div class="card-body d-flex flex-column justify-content-center align-items-center">
                        <i class="material-icons text-white" style="font-size: 48px;">local_florist</i>
                        <span class="card-title h5 text-white mt-2">Plants</span>
                    </div>
                </div>
            </a>
        </div>
        <div class="col-sm-6 col-md-3">
            <a href="/care-tasks" class="text-decoration-none">
                <div class="card bg-success text-center shadow-sm h-100">
                    <div class="card-body d-flex flex-column justify-content-center align-items-center">
                        <i class="material-icons text-white" style="font-size: 48px;">assignment</i>
                        <span class="card-title h5 text-white mt-2">Care Tasks</span>
                    </div>
                </div>
            </a>
        </div>
        <div class="col-sm-6 col-md-3">
            <a href="/species" class="text-decoration-none">
                <div class="card bg-success text-center shadow-sm h-100">
                    <div class="card-body d-flex flex-column justify-content-center align-items-center">
                        <i class="material-icons text-white" style="font-size: 48px;">spa</i>
                        <span class="card-title h5 text-white mt-2">Species</span>
                    </div>
                </div>
            </a>
        </div>
        <div class="col-sm-6 col-md-3">
            <a href="/tags" class="text-decoration-none">
                <div class="card bg-success text-center shadow-sm h-100">
                    <div class="card-body d-flex flex-column justify-content-center align-items-center">
                        <i class="material-icons text-white" style="font-size: 48px;">label</i>
                        <span class="card-title h5 text-white mt-2">Tags</span>
                    </div>
                </div>
            </a>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make("main", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\tools\xampp\htdocs\plantcare\resources\views/home/homePage.blade.php ENDPATH**/ ?>