@extends("main")

@section("topMenu")
<a class="btn btn-primary" href="{{url()->current()}}/create-new">Create new</a>
@endsection

@section("content")
<div class="container">
    <div class="row gy-4">
        @foreach($models as $item)
        <div class="col-sm-12 col-md-6 col-lg-4">
            <div class="card border-success shadow">
                <div class="card-body">
                    <h5 class="card-title">{{$item->Name}}</h5>
                    <hr>
                    <p class="card-text">
                        @foreach($item->PlantTags->where("IsActive", "=", true) as $tag)
                            <span class="badge badge-secondary bg-warning text-black">{{$tag->Tag->Name}}
                                <a href="{{url()->current()}}/delete-tag/{{$tag->Id}}" class="material-icons font-xs text-danger cursor-pointer text-decoration-none">close</a>
                            </span>
                        @endforeach
                    </p>
                </div>
                <div class="card-footer">
                    <div class="btn-group" role="group">
                        <a class="btn btn-primary" href="{{url()->current()}}/edit/{{$item->Id}}">Edit</a>
                        <a class="btn btn-danger" href="{{url()->current()}}/delete/{{$item->Id}}">Delete</a>
                        <a class="btn btn-success" href="{{url()->current()}}/plant-details/{{$item->Id}}">Details</a>
                    </div>
                </div>
            </div>
        </div>
        @endforeach
    </div>
</div>
@endsection
