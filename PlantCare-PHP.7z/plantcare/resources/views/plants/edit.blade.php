@extends("main",["pageTitle"=>"Plants - Create New"])

@section("topMenu")
<a class="btn btn-primary" href="/plants">Back to Plants</a>
@endsection

@section("content")
<div class="container">
    <form method="POST" action="/plants/edit/{{$model->Id}}">
        @csrf
        <div class="row gy-3">
            <div class="col-md-12 col-lg-6 col-xxl-4">
                <div class="form-group">
                    <label for="Name" class="form-label">
                        <i class="material-icons-round align-middle">label</i>
                        Name
                    </label>
                    <input class="form-control validate" value="{{$model->Name}}" name="Name" required>
                </div>
            </div>
            
            <div class="col-md-12 col-lg-6 col-xxl-4">
                <div class="form-group">
                    <label for="Species" class="form-label">
                        <i class="material-icons-round align-middle">category</i>
                        Species
                    </label>
                    <select class="form-control validate" id="SpeciesId" name="SpeciesId" required>
                        <option value="" disabled>Select a species</option>
                        @foreach($speciesList as $species)
                            <option value="{{ $species->Id }}" {{ $species->Id == $model->SpeciesId ? 'selected' : '' }}>{{ $species->Name }}</option>
                        @endforeach
                    </select>
                </div>
            </div>

            <div class="col-md-12 col-lg-6 col-xxl-4">
                <div class="form-group">
                    <label for="WateringFrequency" class="form-label">
                        <i class="material-icons-round align-middle">opacity</i>
                        Watering Frequency
                    </label>
                    <input class="form-control validate" value="{{$model->WateringFrequency}}" name="WateringFrequency" required>
                </div>
            </div>

            <div class="col-md-12 col-lg-6 col-xxl-4">
                <div class="form-group">
                    <label for="SunlightRequirements" class="form-label">
                        <i class="material-icons-round align-middle">wb_sunny</i>
                        Sunlight Requirements
                    </label>
                    <input class="form-control validate" value="{{$model->SunlightRequirements}}" name="SunlightRequirements" required>
                </div>
            </div>
            
            <div class="col-md-12 col-lg-6 col-xxl-4">
                <div class="form-group">
                    <label for="LastWateringDate" class="form-label">
                        <i class="material-icons-round palette-accent-text-color align-middle">today</i>
                        Last Watering Date
                    </label>
                    <input class="form-control validate" type="date" value="{{date('Y-m-d', strtotime($model->LastWateringDate))}}" name="LastWateringDate" required>
                </div>
            </div>
            
            <div class="col-sm-12">
                <button class="btn btn-primary">Save</button>
            </div>
        </div>
    </form>
</div>
@endsection