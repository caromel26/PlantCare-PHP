@extends("main", ["pageTitle" => "Plant Details"])

@section("topMenu")
<a class="btn btn-primary" href="/plants">Back to Plants</a>
@endsection

@section("content")
<div class="container">
    <div class="row mb-3">
        <div class="col-sm-12 d-flex justify-content-between align-items-center">
            <h1 class="mb-0">{{$model->Name}}</h1>
            <!-- <a class="btn btn-primary" href="{plants/edit/{{$model->Id}}">Edit Plant</a> -->
        </div>
    </div>
    <div class="row gy-3 mb-3">
    <div class="col-sm-12 col-md-6 col-lg-3">
        <div class="card">
            <div class="card-body">
                <b class="d-block mb-2">SPECIES</b>
                <p>{{$model->Species->Name}}</p>
            </div>
        </div>
    </div>
    <div class="col-sm-12 col-md-6 col-lg-3">
        <div class="card">
            <div class="card-body">
                <b class="d-block mb-2">WATERING FREQUENCY</b>
                <p>{{$model->WateringFrequency}}</p>
            </div>
        </div>
    </div>
    <div class="col-sm-12 col-md-6 col-lg-3">
        <div class="card">
            <div class="card-body">
                <b class="d-block mb-2">SUNLIGHT REQUIREMENTS</b>
                <p>{{$model->SunlightRequirements}}</p>
            </div>
        </div>
    </div>
    <div class="col-sm-12 col-md-6 col-lg-3">
    <div class="card">
    <div class="card-body d-flex justify-content-between align-items-center">
        <div>
            <b class="d-block mb-2">LAST WATERING DATE</b>
            <p>{{ date('F j, Y', strtotime($model->LastWateringDate)) }}</p>
        </div>
        <form action="{{ route('plant.updateLastWateringDate', ['id' => $model->Id]) }}" method="POST" style="display:inline;">
            @csrf
            <button type="submit" class="btn btn-sm btn-info">Update</button>
        </form>
    </div>
</div>

</div>

</div>

    <div class="row gy-3">
        <!-- Tasks Column -->
        <div class="col-sm-12 col-md-4">
            <div class="card">
                <div class="card-body">
                    <b class="d-block mb-3">TASKS</b>
                    <ul class="nav nav-tabs" id="taskTabs" role="tablist">
                        <li class="nav-item">
                            <a class="nav-link active" id="uncompleted-tab" data-toggle="tab" href="#uncompleted" role="tab" aria-controls="uncompleted" aria-selected="true">Uncompleted</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" id="completed-tab" data-toggle="tab" href="#completed" role="tab" aria-controls="completed" aria-selected="false">Completed</a>
                        </li>
                    </ul>
                    <div class="tab-content" id="taskTabsContent">
                        <!-- Uncompleted Tasks Tab -->
                        <div class="tab-pane fade show active" id="uncompleted" role="tabpanel" aria-labelledby="uncompleted-tab">
                            @foreach($model->PlantCareTasks->where("IsActive", "=", true)->where("CompletionStatus", "=", false) as $task)
                                <div class="task-item mb-3">
                                    <b>{{$task->TaskType->Name}}</b><br>
                                    {{$task->TaskType->Description}}<br>
                                    @if($task->DueDate)
                                        @php
                                            $dueDate = strtotime($task->DueDate);
                                            $today = strtotime(date('Y-m-d'));
                                            $dateColorClass = '';
                                            if ($dueDate == $today) {
                                                $dateColorClass = 'text-warning';
                                            } elseif ($dueDate < $today) {
                                                $dateColorClass = 'text-danger';
                                            }
                                        @endphp
                                        <span class="{{ $dateColorClass }}">Due Date: {{ date('Y-m-d', $dueDate) }}</span><br>
                                    @endif
                                    <form action="{{ route('plant.markTaskCompleted', ['id' => $task->Id]) }}" method="POST" style="display:inline;">
                                        @csrf
                                        <button type="submit" class="btn btn-sm btn-success mt-2">Mark as Completed</button>
                                    </form>
                                    <a class="btn btn-sm btn-danger mt-2" href="{{ route('plant.deleteTask', ['id' => $task->Id]) }}">Delete</a>
                                </div>
                            @endforeach
                            <div id="addTaskForm" style="display: none;">
                                <form action="{{ route('plant.addTask', ['id' => $model->Id]) }}" method="POST">
                                    @csrf
                                    <select name="TaskTypeId" id="taskType" class="form-control">
                                        @foreach($allTasks as $task)
                                            <option value="{{ $task->Id }}">{{ $task->Name }}</option>
                                        @endforeach
                                    </select>
                                    <input type="date" name="DueDate" id="DueDate" class="form-control" value="{{ date('Y-m-d') }}" min="{{ date('Y-m-d') }}" placeholder="Due Date">
                                    <button type="submit" class="btn btn-success mt-2" id="saveTaskBtn">Save</button>
                                    <button type="button" class="btn btn-danger mt-2" id="cancelTaskBtn">Cancel</button>
                                </form>
                            </div>
                            <a class="btn btn-primary mt-2" href="#" id="addTaskBtn">Add Task</a>
                        </div>
                        <!-- Completed Tasks Tab -->
                        <div class="tab-pane fade" id="completed" role="tabpanel" aria-labelledby="completed-tab">
                            @foreach($model->PlantCareTasks->where("CompletionStatus", "=", true) as $task)
                                <div class="task-item mb-3">
                                    <b class="text-success">{{$task->TaskType->Name}}</b><br>
                                    <span class="text-success">{{$task->TaskType->Description}}</span><br>
                                    @if($task->DueDate)
                                    <span class="text-muted">Due Date: {{ date('Y-m-d', strtotime($task->DueDate)) }}</span><br>
                                    @endif
                                </div>
                            @endforeach
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <script>
            document.addEventListener("DOMContentLoaded", function() {
                document.getElementById("addTaskBtn").addEventListener("click", function(event) {
                    event.preventDefault();
                    document.getElementById("addTaskForm").style.display = "block";
                });

                document.getElementById("cancelTaskBtn").addEventListener("click", function(event) {
                    event.preventDefault();
                    document.getElementById("addTaskForm").style.display = "none";
                });
            });
        </script>

    <!-- Notes Column -->
    <div class="col-sm-12 col-md-4">
        <div class="card">
            <div class="card-body">
                <b class="d-block mb-3">NOTES</b>
                @foreach($model->Notes->where("IsActive", "=", true) as $note)
                    <p>
                        {{$note->NoteText}}<br>
                        <a class="btn btn-sm btn-danger" href="{{ route('plant.deleteNote', ['id' => $note->Id]) }}">Delete</a>
                    </p><br>
                @endforeach
                <button class="btn btn-primary mt-2" id="addNoteBtn">Add Note</button>
                <form id="addNoteForm" style="display: none;" action="{{ route('plant.addNote', ['id' => $model->Id]) }}" method="POST">
                    @csrf
                    <textarea class="form-control validate rounded-0" name="NoteText" id="NoteText" rows="3" placeholder="Enter your note">{{$model->NoteText}}</textarea>
                    <div class="mt-2">
                        <button type="submit" class="btn btn-success">Save</button>
                        <button type="button" class="btn btn-danger ml-2" id="cancelAddNoteBtn">Cancel</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <script>
        document.addEventListener("DOMContentLoaded", function() {
            document.getElementById("addNoteBtn").addEventListener("click", function(event) {
                event.preventDefault();
                document.getElementById("addNoteForm").style.display = "block";
            });

            document.getElementById("cancelAddNoteBtn").addEventListener("click", function(event) {
                event.preventDefault();
                document.getElementById("addNoteForm").style.display = "none";
            });
        });
    </script>

        <!-- Tags Column -->
        <div class="col-sm-12 col-md-4">
            <div class="card">
                <div class="card-body">
                <b class="d-block mb-3">TAGS</b>
                    <div class="tag-container">
                        @php $tagCount = 0; @endphp
                        @foreach($model->PlantTags->where("IsActive", "=", true) as $tag)
                            @if($tagCount % 3 == 0)
                                <div class="tag-row">
                            @endif
                            <span class="badge badge-secondary bg-warning text-black">
                                {{$tag->Tag->Name}}
                                <a href="{{ route('plant.deleteTag', ['id' => $tag->Id]) }}" class="material-icons font-xs text-danger cursor-pointer text-decoration-none">close</a>
                            </span>
                            @php $tagCount++; @endphp
                            @if($tagCount % 3 == 0)
                                </div>
                            @endif
                        @endforeach
                        @if($tagCount % 3 != 0)
                            </div>
                        @endif
                    </div>
                    <div id="addTagForm" style="display: none;">
                        <form action="{{ route('plant.addTag', ['id' => $model->Id]) }}" method="POST">
                            @csrf
                            <select name="TagId" id="TagId" class="form-control">
                            @foreach($allTags as $tag)
                                @php
                                    $existingTag = $model->PlantTags->where('TagId', $tag->Id)->first();
                                @endphp
                                @if((!$existingTag || $existingTag->IsActive==0) && $tag->IsActive)
                                    <option value="{{ $tag->Id }}">{{ $tag->Name }}</option>
                                @endif
                            @endforeach
                            </select>
                            <button type="submit" class="btn btn-success mt-2" id="saveTagBtn">Save</button>
                            <button type="button" class="btn btn-danger mt-2" id="cancelTagBtn">Cancel</button>
                        </form>
                    </div>
                    <a class="btn btn-primary mt-2" href="#" id="addTagBtn">Add Tag</a>
                </div>
            </div>
        </div>
        <script>
            document.addEventListener("DOMContentLoaded", function() {
                document.getElementById("addTagBtn").addEventListener("click", function(event) {
                    event.preventDefault();
                    document.getElementById("addTagForm").style.display = "block";
                });

                document.getElementById("cancelTagBtn").addEventListener("click", function(event) {
                    event.preventDefault();
                    document.getElementById("addTagForm").style.display = "none";
                });
            });
        </script>
    </div>
</div>
@endsection