@extends("main", ["pageTitle" => "Plants - Create New"])

@section("topMenu")
<a class="btn btn-primary" href="/plants">Back to Plants</a>
@endsection

@section("content")
<div class="container">
    <form method="POST" action="/plants/create-new">
        @csrf
        <div class="row gy-3">
            <div class="col-md-12 col-lg-6 col-xxl-4">
                <div class="form-group">
                    <label for="Name" class="form-label">
                        <i class="material-icons-round align-middle">label</i>
                        Name
                    </label>
                    <input type="text" class="form-control validate" id="Name" name="Name" value="{{ old('Name') }}" required>
                </div>
            </div>
            
            <div class="col-md-12 col-lg-6 col-xxl-4">
                <div class="form-group">
                    <label for="Species" class="form-label">
                        <i class="material-icons-round align-middle">category</i>
                        Species
                    </label>
                    <select class="form-control validate" id="SpeciesId" name="SpeciesId" required>
                        <option value="" disabled selected>Select a species</option>
                        @foreach($speciesList as $species)
                            <option value="{{ $species->Id }}">{{ $species->Name }}</option>
                        @endforeach
                    </select>
                </div>
            </div>

            <div class="col-md-12 col-lg-6 col-xxl-4">
                <div class="form-group">
                    <label for="WateringFrequency" class="form-label">
                        <i class="material-icons-round align-middle">opacity</i>
                        Watering Frequency
                    </label>
                    <input type="text" class="form-control validate" id="WateringFrequency" name="WateringFrequency" value="{{ old('WateringFrequency') }}" required>
                </div>
            </div>

            <div class="col-md-12 col-lg-6 col-xxl-4">
                <div class="form-group">
                    <label for="SunlightRequirements" class="form-label">
                        <i class="material-icons-round align-middle">wb_sunny</i>
                        Sunlight Requirements
                    </label>
                    <input type="text" class="form-control validate" id="SunlightRequirements" name="SunlightRequirements" value="{{ old('SunlightRequirements') }}" required>
                </div>
            </div>
            
            <div class="col-md-12 col-lg-6 col-xxl-4">
                <div class="form-group">
                    <label for="LastWateringDate" class="form-label">
                        <i class="material-icons-round palette-accent-text-color align-middle">today</i>
                        Last Watering Date
                    </label>
                    <input type="date" class="form-control validate" id="LastWateringDate" name="LastWateringDate" value="{{ old('LastWateringDate', date('Y-m-d')) }}" required>
                </div>
            </div>
            
            <div class="col-12">
                <button type="submit" class="btn btn-primary">Create</button>
            </div>
        </div>
    </form>
</div>
@endsection
