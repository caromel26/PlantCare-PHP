@extends("main", ["pageTitle" => "API Plant Search"])

@section("content")
<div class="container">
    <form method="GET" action="/api/plants">
        <div class="row gy-3">
            <div class="col-md-12">
                <div class="input-group">
                    <input type="text" class="form-control" name="query" placeholder="Search for plants...">
                    <button class="btn btn-primary" type="submit">Search</button>
                </div>
            </div>
        </div>
    </form>
    
    <div class="row gy-4 mt-4">
        @if(isset($plants))
            @foreach($plants as $plant)
                <div class="col-md-6 col-lg-4">
                    <div class="card">
                        <div class="d-flex">
                            <img src="{{ $plant['image_url'] ?? 'placeholder.jpg' }}" class="card-img-top img-fluid" style="width: 150px; height: 150px; object-fit: cover;" alt="Plant Image">
                            <div class="card-body">
                                <h5 class="card-title">{{ $plant['common_name'] }}</h5>
                                <p class="card-text"><b>Scientific Name:</b> {{ $plant['scientific_name'] }}</p>
                                <p class="card-text"><b>Family:</b> {{ $plant['family'] }}</p>
                                <p class="card-text"><b>Genus:</b> {{ $plant['genus'] }}</p>
                                <p class="card-text"><b>Family Common Name:</b> {{ $plant['family_common_name'] }}</p>
                            </div>
                        </div>
                    </div>
                </div>
            @endforeach
        @elseif(isset($error))
            <div class="alert alert-danger">{{ $error }}</div>
        @else
            <p>No plants found. Try searching for something else.</p>
        @endif
    </div>
</div>
@endsection
