@extends('main', ["pageTitle" => "Plants in need of " . $task->Name])

@section('topMenu')
<a class="btn btn-primary" href="{{ url('/care-tasks') }}">Back to Tasks</a>
@endsection

@section('content')
<div class="container">
    <h1 class="my-4">Plants in need of {{$task->Name}}</h1>
    <div class="row gy-4">
        @foreach($plants as $plant)
        <div class="col-sm-12 col-md-6 col-lg-3">
            <div class="card border-success shadow">
                <div class="card-body">
                    <h5 class="card-title">{{$plant->Name}}</h5>
                    <p>Watering Frequency: {{$plant->WateringFrequency}}</p>
                    <p>Sunlight Requirements: {{$plant->SunlightRequirements}}</p>
                    <p>Last Watering Date: {{$plant->LastWateringDate}}</p>
                </div>
            </div>
        </div>
        @endforeach
    </div>
</div>
@endsection
