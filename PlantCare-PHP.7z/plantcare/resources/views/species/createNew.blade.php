@extends("main",["pageTitle"=>"Species - Create New"])

@section("topMenu")
<a class="btn btn-primary" href="/species">Back to Species</a>
@endsection

@section("content")
<div class="container">
    <form method="POST" action="/species/create-new">
        @csrf
        <div class="row gy-3 mb-3">
            <div class="col-md-12 col-lg-6 col-xxl-4">
                <div class="input-group">
                    <label class="input-group-text">
                        <i class="material-icons-round align-middle">label</i>
                        Name
                    </label>
                    <input class="form-control validate" value="{{$model->Name}}" name="Name">
                </div>
            </div>
        </div>
        <div class="row gy-3 mb-3">
            <div class="col-md-12 col-lg-6 col-xxl-4">
                <div class="input-group">
                    <label class="input-group-text w-100">
                        <i class="material-icons-round align-middle">notes</i>
                        Description
                    </label>
                    <textarea class="form-control validate rounded-0" rows="5" name="Description">{{$model->Description}}</textarea>
                </div>
            </div>
        </div>
        <div class="row gy-3">
            <div class="col-sm-12">
                <button class="btn btn-primary">Create</button>
            </div>
        </div>
    </form>
</div>
@endsection
