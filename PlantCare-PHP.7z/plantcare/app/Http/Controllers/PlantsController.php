<?php

namespace App\Http\Controllers;

use App\Models\Plant;
use App\Models\PlantTag;
use App\Models\Tag;
use App\Models\PlantCareTask;
use App\Models\TaskType;
use App\Models\Note;
use App\Models\Species;
use Illuminate\Http\Request;

class PlantsController extends Controller
{
    public function index()
    {
        $models = Plant::where("IsActive","=",true)->get();
        return view("plants.index", ["models"=>$models,"pageTitle"=>"Plants"]);
    }

    #region Base
    public function edit($id)
    {
        $model = Plant::find($id);
        // $tags = Tag::where("IsActive","=",true)->get();
        // $notes = Note::where("IsActive","=",true)->get();
        // $tasks = PlantCareTask::where("IsActive","=",true)->get(); , "tags"=>$tags, "notes"=>$notes, "tasks"=>$tasks
        $speciesList = Species::all();

        return view("plants.edit", compact('speciesList'), ["model"=>$model]);
    }

    public function update($id, Request $request)
    {
        $model = Plant::find($id);
        $model->UserId=1; //change it to current user id
        $model->SpeciesId=$request->input("SpeciesId");
        $model->Name=$request->input("Name");
        $model->WateringFrequency=$request->input("WateringFrequency");
        $model->SunlightRequirements=$request->input("SunlightRequirements");
        $model->LastWateringDate=$request->input("LastWateringDate");

        $model->save();

        return redirect("/plants");
    }

    public function delete($id)
    {
        $model = Plant::find($id);
        $model->IsActive=false;
        $model->DeletedAt=date('Y-m-d H:i:s');
        
        $model->save();
        return redirect("/plants");
    }

    public function createNew()
    {
        $model = new Plant();

        $model->LastWateringDate=date("d-m-Y");
        $speciesList = Species::all();

        return view("plants.createNew", compact('speciesList'), ["model"=>$model]);
    }

    public function addToDb(Request $request)
    {
        $model = new Plant();

        $model->UserId=1; //change it to current user id
        $model->SpeciesId=$request->input("SpeciesId");
        $model->Name=$request->input("Name");
        $model->WateringFrequency=$request->input("WateringFrequency");
        $model->SunlightRequirements=$request->input("SunlightRequirements");
        $model->LastWateringDate=$request->input("LastWateringDate");
        $model->IsActive=true;

        $model->save();

        return redirect("/plants")->with('success', 'Plant created successfully!');
    }

    public function plantDetails($id)
    {
        $model = Plant::find($id);
        $allTasks = TaskType::where('IsActive', true)->get();
        $allTags = Tag::where('IsActive', true)->get();
        return view("plants.plantDetails", ["model"=>$model, "allTasks"=>$allTasks, "allTags"=>$allTags]);
    }

    public function updateLastWateringDate($id)
    {
        $plant = Plant::find($id);

        $plant->LastWateringDate = date('Y-m-d');

        $plant->save();

        return back();
    }

    #endregion

    #region Tags
    public function addTag($id)
    {
        $tag = Tag::where("IsActive","=",true)->get();
        
        return view("plants.addTag", ["tag"=>$tag, "id"=>$id]);
    }

    public function addTagToDb($id, Request $request)
    {
        $plantTag = new PlantTag();

        $plantTag->PlantId=$id;
        $plantTag->TagId=$request->input("TagId");
        $plantTag->IsActive=true;

        $plantTag->save();

        return back();
    }

    public function deleteTag($id)
    {
        $plantTag = PlantTag::find($id);
        $plantTag->IsActive=false;
        $plantTag->DeletedAt=date('Y-m-d H:i:s');

        $plantTag->save();

        return back();
    }
    #endregion

    #region Tasks
    public function addTask($id)
    {
        $task = PlantCareTask::where("IsActive","=",true)->get();
        
        return view("plants.addTask", ["task"=>$task, "id"=>$id]);
    }

    public function addTaskToDb($id, Request $request)
    {
        $task = new PlantCareTask();

        $task->PlantId=$id;
        $task->TaskTypeId=$request->input("TaskTypeId");
        $task->DueDate=$request->input("DueDate");
        $task->CompletionStatus=0;
        $task->IsActive=true;

        $task->save();

        return back();
    }

    public function deleteTask($id)
    {
        $task = PlantCareTask::find($id);
        $task->IsActive=false;
        $task->DeletedAt=date('Y-m-d H:i:s');

        $task->save();

        return back();
    }

    public function markTaskAsCompleted($id)
    {
        $task = PlantCareTask::find($id);
        $task->CompletionStatus=true;

        $task->save();

        return back();
    }
    #endregion

    #region Notes
    public function addNote($id)
    {
        $note = Note::where("IsActive","=",true)->get();
        
        return view("plants.addNote", ["note"=>$note, "id"=>$id]);
    }

    public function addNoteToDb($id, Request $request)
    {
        $note = new Note();

        $note->PlantId=$id;
        $note->NoteText=$request->input("NoteText");
        $note->IsActive=true;

        $note->save();

        return back();
    }

    public function deleteNote($id)
    {
        $note = Note::find($id);
        $note->IsActive=false;
        $note->DeletedAt=date('Y-m-d H:i:s');

        $note->save();

        return back();
    }
    #endregion
}