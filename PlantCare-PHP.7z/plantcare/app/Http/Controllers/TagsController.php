<?php

namespace App\Http\Controllers;

use App\Models\Tag;
use App\Models\PlantTag;
use App\Models\Plant;
use Illuminate\Http\Request;

class TagsController extends Controller
{
    public function index()
    {
        $models = Tag::where("IsActive","=",true)->get();
        return view("tags.index", ["models"=>$models,"pageTitle"=>"Tags"]);
    }

    public function edit($id)
    {
        $model = Tag::find($id);
        return view("tags.edit", ["model"=>$model]);
    }

    public function update($id, Request $request)
    {
        $model = Tag::find($id);
        $model->Name=$request->input("Name");
        $model->Description=$request->input("Description");

        $model->save();

        return redirect("/tags");
    }

    public function delete($id)
    {
        $model = Tag::find($id);
        $model->IsActive=false;
        $model->DeletedAt=date('Y-m-d H:i:s');

        $model->save();

        return redirect("/tags");
    }

    public function createNew()
    {
        $model = new Tag();

        return view("tags.createNew", ["model"=>$model]);
    }

    public function addToDb(Request $request)
    {
        $model = new Tag();

        $model->Name=$request->input("Name");
        $model->Description=$request->input("Description");
        $model->IsActive=true;

        $model->save();

        return redirect("/tags");
    }

    public function seePlants($id)
    {
        $tags = Tag::findOrFail($id);
        $plants = Plant::whereHas('plantTags', function($query) use ($id) {
            $query->where('TagId', $id)
                  ->where('IsActive', 1); // Check if PlantTag is active
        })
        ->where('IsActive', 1) // Check if Plant is active
        ->get();

        return view('tags.plants', compact('tags', 'plants'));
    }
}
