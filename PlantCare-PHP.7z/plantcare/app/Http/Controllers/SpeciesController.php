<?php

namespace App\Http\Controllers;

use App\Models\Species;
use App\Models\Plant;
use Illuminate\Http\Request;

class SpeciesController extends Controller
{
    public function index()
    {
        $models = Species::where("IsActive","=",true)->get();
        return view("species.index", ["models"=>$models,"pageTitle"=>"Species"]);
    }

    public function edit($id)
    {
        $model = Species::find($id);
        return view("species.edit", ["model"=>$model]);
    }

    public function update($id, Request $request)
    {
        $model = Species::find($id);
        $model->Name=$request->input("Name");
        $model->Description=$request->input("Description");

        $model->save();

        return redirect("/species");
    }

    public function delete($id)
    {
        $model = Species::find($id);
        $model->IsActive=false;
        $model->DeletedAt=date('Y-m-d H:i:s');

        $model->save();

        return redirect("/species");
    }

    public function createNew()
    {
        $model = new Species();

        return view("species.createNew", ["model"=>$model]);
    }

    public function addToDb(Request $request)
    {
        $model = new Species();

        $model->Name=$request->input("Name");
        $model->Description=$request->input("Description");
        $model->IsActive=true;

        $model->save();

        return redirect("/species");
    }

    public function seePlants($id)
    {
        $species = Species::findOrFail($id);
        $plants = Plant::where('SpeciesId', $id)
                   ->where('IsActive', 1)
                   ->get();

        return view('species.plants', compact('species', 'plants'));
    }
}
