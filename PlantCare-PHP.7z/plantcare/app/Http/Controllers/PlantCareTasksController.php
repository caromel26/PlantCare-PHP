<?php

namespace App\Http\Controllers;

use App\Models\PlantCareTask;
use Illuminate\Http\Request;

class PlantCareTasksController extends Controller
{
    public function index()
    {
        $models = PlantCareTask::where("IsActive","=",true)->get();
        return view("plantCareTasks.index", ["models"=>$models,"pageTitle"=>"Plant Care Tasks"]);
    }

    public function edit($id)
    {
        $model = PlantCareTask::find($id);
        return view("plantCareTasks.edit", ["model"=>$model]);
    }

    public function update($id, Request $request)
    {
        $model = PlantCareTask::find($id);
        $model->PlantId=$request->input("PlantId");
        $model->TaskTypeId=$request->input("TaskTypeId");
        $model->DueDate=$request->input("DueDate");
        $model->CompletionStatus=$request->input("CompletionStatus");

        $model->save();

        return redirect("/plantCareTasks");
    }

    public function delete($id)
    {
        $model = PlantCareTask::find($id);
        $model->IsActive=false;
        $model->DeletedAt=date('Y-m-d H:i:s');

        $model->save();

        return redirect("/plantCareTasks");
    }

    public function createNew()
    {
        $model = new PlantCareTask();

        return view("plantCareTasks.createNew", ["model"=>$model]);
    }

    public function addToDb(Request $request)
    {
        $model = new PlantCareTask();

        $model->PlantId=$request->input("PlantId");
        $model->TaskTypeId=$request->input("TaskTypeId");
        $model->DueDate=$request->input("DueDate");
        $model->CompletionStatus=$request->input("CompletionStatus");
        $model->IsActive=true;

        $model->save();

        return redirect("/plantCareTasks");
    }

    public function taskDetails($id)
    {
        $model = PlantCareTask::find($id);
        return view("plantCareTasks.taskDetails", ["model"=>$model]);
    }
}
