<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Http;

class ApiController extends Controller
{
    private $apiKey;

    public function __construct()
    {
        $this->apiKey = env('TREFLE_API_KEY');
    }

    public function getPlants(Request $request)
    {
        $query = $request->input('query', '');

        $response = Http::withOptions([
            'verify' => false,
        ])->get("https://trefle.io/api/v1/plants/search", [
            'token' => $this->apiKey,
            'q' => $query
        ]);

        if ($response->successful()) {
            $plants = $response->json()['data'];
            return view('api.index', compact('plants'));
        }

        return view('api.index')->with('info', 'Please input a search query.');
    }
}
