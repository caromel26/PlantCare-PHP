<?php

namespace App\Http\Controllers;

use App\Models\TaskType;
use App\Models\Plant;
use Illuminate\Http\Request;

class TaskTypesController extends Controller
{
    public function index()
    {
        $models = TaskType::where("IsActive","=",true)->get();
        return view("careTasks.index", ["models"=>$models,"pageTitle"=>"Task Types"]);
    }

    public function edit($id)
    {
        $model = TaskType::find($id);
        return view("careTasks.edit", ["model"=>$model]);
    }

    public function update($id, Request $request)
    {
        $model = TaskType::find($id);
        $model->Name=$request->input("Name");
        $model->Description=$request->input("Description");

        $model->save();

        return redirect("/care-tasks");
    }

    public function delete($id)
    {
        $model = TaskType::find($id);
        $model->IsActive=false;
        $model->DeletedAt=date('Y-m-d H:i:s');

        $model->save();

        return redirect("/care-tasks");
    }

    public function createNew()
    {
        $model = new TaskType();

        return view("careTasks.createNew", ["model"=>$model]);
    }

    public function addToDb(Request $request)
    {
        $model = new TaskType();

        $model->Name=$request->input("Name");
        $model->Description=$request->input("Description");
        $model->IsActive=true;

        $model->save();

        return redirect("/care-tasks");
    }

    public function seePlants($id)
    {
        $task = TaskType::findOrFail($id);

        $plants = Plant::where('IsActive', 1) 
                   ->whereHas('plantCareTasks', function($query) use ($id) {
                        $query->where('TaskTypeId', $id)
                              ->where('IsActive', 1); // Check if PlantTask is active
                   })
                   ->get();

        return view('careTasks.plants', compact('task', 'plants'));
    }
}