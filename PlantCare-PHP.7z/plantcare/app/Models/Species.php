<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Species extends Model
{
    use HasFactory;
    const CREATED_AT = "CreatedAt";
    const UPDATED_AT = "UpdatedAt";
    protected $table = "Species";
    protected $primaryKey = "Id"; 

    public function Plants()
    {
        return $this->hasMany(Plant::class,"SpeciesId");
    }
}
