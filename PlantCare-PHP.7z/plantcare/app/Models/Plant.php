<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Plant extends Model
{
    use HasFactory;
    const CREATED_AT = "CreatedAt";
    const UPDATED_AT = "UpdatedAt";
    protected $table = "Plants";
    protected $primaryKey = "Id"; 

    public function PlantTags()
    {
        return $this->hasMany(PlantTag::class,"PlantId");
    }

    public function PlantCareTasks()
    {
        return $this->hasMany(PlantCareTask::class,"PlantId");
    }

    public function Notes()
    {
        return $this->hasMany(Note::class,"PlantId");
    }

    public function Species()
    {
        return $this->belongsTo(Species::class,"SpeciesId");
    }
}