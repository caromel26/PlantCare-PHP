<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Tag extends Model
{
    use HasFactory;
    const CREATED_AT = "CreatedAt";
    const UPDATED_AT = "UpdatedAt";
    protected $table = "Tags";
    protected $primaryKey = "Id"; 

    public function PlantTags()
    {
        return $this->hasMany(PlantTag::class,"TagId");
    }
}
