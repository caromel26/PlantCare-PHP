<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class PlantTag extends Model
{
    use HasFactory;
    const CREATED_AT = "CreatedAt";
    const UPDATED_AT = "UpdatedAt";
    protected $table = "PlantTags";
    protected $primaryKey = "Id"; 

    public function Plant()
    {
        return $this->belongsTo(Plant::class,"PlantId");
    }

    public function Tag()
    {
        return $this->belongsTo(Tag::class,"TagId");
    }
}
