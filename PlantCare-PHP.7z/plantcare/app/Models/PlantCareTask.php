<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class PlantCareTask extends Model
{
    use HasFactory;
    const CREATED_AT = "CreatedAt";
    const UPDATED_AT = "UpdatedAt";
    protected $table = "PlantCareTasks";
    protected $primaryKey = "Id";

    public function Plant()
    {
        return $this->belongsTo(Plant::class,"PlantId");
    }

    public function TaskType()
    {
        return $this->belongsTo(TaskType::class,"TaskTypeId");
    }
}
