<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Note extends Model
{
    use HasFactory;
    const CREATED_AT = "CreatedAt";
    const UPDATED_AT = "UpdatedAt";
    protected $table = "Notes";
    protected $primaryKey = "Id"; 

    public function Plant()
    {
        return $this->belongsTo(Plant::class,"PlantId");
    }
}
