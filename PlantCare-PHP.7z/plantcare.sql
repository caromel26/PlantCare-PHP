-- phpMyAdmin SQL Dump
-- version 5.0.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 27, 2024 at 12:29 PM
-- Server version: 10.4.16-MariaDB
-- PHP Version: 7.4.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `plantcare`
--

-- --------------------------------------------------------

--
-- Table structure for table `images`
--

CREATE TABLE `images` (
  `Id` int(11) NOT NULL,
  `PlantId` int(11) NOT NULL,
  `ImageUrl` varchar(1000) CHARACTER SET utf8 DEFAULT NULL,
  `IsActive` bit(1) NOT NULL,
  `CreatedAt` datetime NOT NULL,
  `UpdatedAt` datetime DEFAULT NULL,
  `DeletedAt` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_polish_ci;

-- --------------------------------------------------------

--
-- Table structure for table `migrations`
--

CREATE TABLE `migrations` (
  `id` int(10) UNSIGNED NOT NULL,
  `migration` varchar(255) COLLATE utf8_polish_ci NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_polish_ci;

--
-- Dumping data for table `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(1, '2024_05_07_000658_create_sessions_table', 1);

-- --------------------------------------------------------

--
-- Table structure for table `notes`
--

CREATE TABLE `notes` (
  `Id` int(11) NOT NULL,
  `PlantId` int(11) NOT NULL,
  `NoteText` varchar(1000) CHARACTER SET utf8 NOT NULL,
  `IsActive` bit(1) NOT NULL,
  `CreatedAt` datetime NOT NULL,
  `UpdatedAt` datetime DEFAULT NULL,
  `DeletedAt` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_polish_ci;

--
-- Dumping data for table `notes`
--

INSERT INTO `notes` (`Id`, `PlantId`, `NoteText`, `IsActive`, `CreatedAt`, `UpdatedAt`, `DeletedAt`) VALUES
(11, 2, 'Some note', b'1', '2024-05-07 12:54:21', '2024-05-07 12:54:21', NULL),
(12, 1, 'test note', b'0', '2024-05-07 13:01:35', '2024-05-27 03:14:26', '2024-05-27 03:14:26'),
(13, 1, 'xsxascsac', b'1', '2024-05-27 03:14:24', '2024-05-27 03:14:24', NULL),
(14, 4, 'dsadasdasd', b'0', '2024-05-27 10:02:00', '2024-05-27 10:06:31', '2024-05-27 10:06:31'),
(15, 5, 'example', b'1', '2024-05-27 10:15:16', '2024-05-27 10:15:16', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `plantcaretasks`
--

CREATE TABLE `plantcaretasks` (
  `Id` int(11) NOT NULL,
  `PlantId` int(11) NOT NULL,
  `TaskTypeId` int(11) NOT NULL,
  `DueDate` datetime NOT NULL,
  `CompletionStatus` bit(1) NOT NULL,
  `IsActive` bit(1) NOT NULL,
  `CreatedAt` datetime NOT NULL,
  `UpdatedAt` datetime DEFAULT NULL,
  `DeletedAt` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_polish_ci;

--
-- Dumping data for table `plantcaretasks`
--

INSERT INTO `plantcaretasks` (`Id`, `PlantId`, `TaskTypeId`, `DueDate`, `CompletionStatus`, `IsActive`, `CreatedAt`, `UpdatedAt`, `DeletedAt`) VALUES
(1, 1, 1, '2024-05-07 12:09:29', b'1', b'1', '2024-05-07 12:09:29', '2024-05-27 03:14:17', NULL),
(2, 1, 2, '2024-05-07 12:09:29', b'0', b'1', '2024-05-07 12:09:29', '2024-05-07 12:09:29', NULL),
(3, 4, 1, '2024-05-30 00:00:00', b'1', b'1', '2024-05-27 10:01:50', '2024-05-27 10:02:15', NULL),
(4, 4, 1, '2024-05-31 00:00:00', b'0', b'0', '2024-05-27 10:02:13', '2024-05-27 10:02:19', '2024-05-27 10:02:19'),
(5, 1, 1, '2024-05-27 00:00:00', b'0', b'1', '2024-05-27 10:10:50', '2024-05-27 10:10:50', NULL),
(6, 1, 1, '2024-05-31 00:00:00', b'0', b'1', '2024-05-27 10:10:57', '2024-05-27 10:10:57', NULL),
(7, 5, 1, '2024-05-29 00:00:00', b'0', b'1', '2024-05-27 10:15:22', '2024-05-27 10:15:22', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `plants`
--

CREATE TABLE `plants` (
  `Id` int(11) NOT NULL,
  `UserId` int(11) NOT NULL,
  `SpeciesId` int(11) DEFAULT NULL,
  `Name` varchar(255) CHARACTER SET utf8 NOT NULL,
  `WateringFrequency` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `SunlightRequirements` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `LastWateringDate` datetime DEFAULT NULL,
  `IsActive` bit(1) NOT NULL,
  `CreatedAt` datetime NOT NULL,
  `UpdatedAt` datetime DEFAULT NULL,
  `DeletedAt` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_polish_ci;

--
-- Dumping data for table `plants`
--

INSERT INTO `plants` (`Id`, `UserId`, `SpeciesId`, `Name`, `WateringFrequency`, `SunlightRequirements`, `LastWateringDate`, `IsActive`, `CreatedAt`, `UpdatedAt`, `DeletedAt`) VALUES
(1, 1, 1, 'Red Rose', 'Twice a week', 'Direct sunlight', '2024-05-07 12:09:29', b'1', '2024-05-07 12:09:29', '2024-05-07 12:09:29', NULL),
(2, 1, 1, 'Monstera Deliciosa', 'once a week', 'half sunny', '2024-05-27 00:00:00', b'1', '2024-05-07 12:11:02', '2024-05-27 10:28:34', NULL),
(4, 1, 1, 'Fikus', 'twice a month', 'sunny', '2024-05-27 00:00:00', b'1', '2024-05-27 10:01:41', '2024-05-27 10:02:43', NULL),
(5, 1, 2, 'Snake', 'Every 2-3 weeks', 'Low to moderate indirect light', '2024-05-27 00:00:00', b'1', '2024-05-27 10:14:29', '2024-05-27 10:28:07', NULL),
(6, 1, 3, 'Fiddle Leaf', 'Once a week', 'Bright indirect light', '2024-05-27 00:00:00', b'1', '2024-05-27 10:14:52', '2024-05-27 10:14:52', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `planttags`
--

CREATE TABLE `planttags` (
  `Id` int(11) NOT NULL,
  `PlantId` int(11) NOT NULL,
  `TagId` int(11) NOT NULL,
  `IsActive` bit(1) NOT NULL,
  `CreatedAt` datetime NOT NULL,
  `UpdatedAt` datetime DEFAULT NULL,
  `DeletedAt` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_polish_ci;

--
-- Dumping data for table `planttags`
--

INSERT INTO `planttags` (`Id`, `PlantId`, `TagId`, `IsActive`, `CreatedAt`, `UpdatedAt`, `DeletedAt`) VALUES
(1, 1, 1, b'0', '2024-05-07 12:09:29', '2024-05-07 10:09:59', '2024-05-07 10:09:59'),
(2, 1, 2, b'1', '2024-05-07 12:09:29', '2024-05-07 12:09:29', NULL),
(3, 2, 3, b'1', '2024-05-07 12:11:02', '2024-05-07 12:11:02', NULL),
(4, 1, 1, b'1', '2024-05-27 03:14:09', '2024-05-27 03:14:09', NULL),
(5, 4, 1, b'0', '2024-05-27 10:02:05', '2024-05-27 10:06:36', '2024-05-27 10:06:36'),
(6, 5, 1, b'1', '2024-05-27 10:15:08', '2024-05-27 10:15:08', NULL),
(7, 5, 3, b'0', '2024-05-27 10:15:11', '2024-05-27 10:15:39', '2024-05-27 10:15:39'),
(8, 5, 2, b'1', '2024-05-27 10:15:29', '2024-05-27 10:15:29', NULL),
(9, 5, 4, b'1', '2024-05-27 10:15:31', '2024-05-27 10:15:31', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `sessions`
--

CREATE TABLE `sessions` (
  `id` varchar(255) COLLATE utf8_polish_ci NOT NULL,
  `user_id` bigint(20) UNSIGNED DEFAULT NULL,
  `ip_address` varchar(45) COLLATE utf8_polish_ci DEFAULT NULL,
  `user_agent` text COLLATE utf8_polish_ci DEFAULT NULL,
  `payload` longtext COLLATE utf8_polish_ci NOT NULL,
  `last_activity` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_polish_ci;

--
-- Dumping data for table `sessions`
--

INSERT INTO `sessions` (`id`, `user_id`, `ip_address`, `user_agent`, `payload`, `last_activity`) VALUES
('Ue5nN8V85BFtI6CsEl9vKlvrCuujISV0ZyIINFJj', NULL, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/123.0.0.0 Safari/537.36 OPR/109.0.0.0', 'YTo0OntzOjY6Il90b2tlbiI7czo0MDoiaENVSzNZbGhpdWNodEZTckZPQmdBRFdRUURBVFBvaGtsTmlBVzlBZiI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MjE6Imh0dHA6Ly9sb2NhbGhvc3Q6ODAwMCI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fXM6NTA6ImxvZ2luX3dlYl81OWJhMzZhZGRjMmIyZjk0MDE1ODBmMDE0YzdmNThlYTRlMzA5ODlkIjtOO30=', 1716805720);

-- --------------------------------------------------------

--
-- Table structure for table `species`
--

CREATE TABLE `species` (
  `Id` int(11) NOT NULL,
  `Name` varchar(255) CHARACTER SET utf8 NOT NULL,
  `Description` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `IsActive` bit(1) NOT NULL,
  `CreatedAt` datetime NOT NULL,
  `UpdatedAt` datetime DEFAULT NULL,
  `DeletedAt` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_polish_ci;

--
-- Dumping data for table `species`
--

INSERT INTO `species` (`Id`, `Name`, `Description`, `IsActive`, `CreatedAt`, `UpdatedAt`, `DeletedAt`) VALUES
(1, 'Rose', 'A beautiful flowering plant', b'1', '2024-05-07 12:09:29', '2024-05-07 12:09:29', NULL),
(2, 'Snake Plant', 'A hardy, low-maintenance plant with long, upright leaves', b'1', '2024-05-27 10:12:43', '2024-05-27 10:12:43', NULL),
(3, 'Fiddle Leaf Fig', 'A popular indoor plant with large, fiddle-shaped leaves', b'1', '2024-05-27 10:12:56', '2024-05-27 10:12:56', NULL),
(4, 'Succulent', 'Plants with fleshy leaves or stems adapted to storing water', b'1', '2024-05-27 10:13:08', '2024-05-27 10:13:08', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `tags`
--

CREATE TABLE `tags` (
  `Id` int(11) NOT NULL,
  `Name` varchar(255) CHARACTER SET utf8 NOT NULL,
  `Description` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `IsActive` bit(1) NOT NULL,
  `CreatedAt` datetime NOT NULL,
  `UpdatedAt` datetime DEFAULT NULL,
  `DeletedAt` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_polish_ci;

--
-- Dumping data for table `tags`
--

INSERT INTO `tags` (`Id`, `Name`, `Description`, `IsActive`, `CreatedAt`, `UpdatedAt`, `DeletedAt`) VALUES
(1, 'Indoor', 'Plants suitable for indoor environments', b'1', '2024-05-07 12:09:29', '2024-05-07 12:09:29', NULL),
(2, 'Outdoor', 'Plants suitable for outdoor environments', b'1', '2024-05-07 12:09:29', '2024-05-07 12:09:29', NULL),
(3, 'Variegata', 'A variegated form of Monstera Deliciosa', b'1', '2024-05-07 12:11:02', '2024-05-27 10:11:42', NULL),
(4, 'Low Maintenance', 'Plants that require minimal care', b'1', '2024-05-27 10:12:25', '2024-05-27 10:12:25', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `tasktypes`
--

CREATE TABLE `tasktypes` (
  `Id` int(11) NOT NULL,
  `Name` varchar(255) CHARACTER SET utf8 NOT NULL,
  `Description` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `IsActive` bit(1) NOT NULL,
  `CreatedAt` datetime NOT NULL,
  `UpdatedAt` datetime DEFAULT NULL,
  `DeletedAt` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_polish_ci;

--
-- Dumping data for table `tasktypes`
--

INSERT INTO `tasktypes` (`Id`, `Name`, `Description`, `IsActive`, `CreatedAt`, `UpdatedAt`, `DeletedAt`) VALUES
(1, 'Watering', 'Regular watering task', b'1', '2024-05-07 12:09:29', '2024-05-07 12:09:29', NULL),
(2, 'Pruning', 'Trimming and pruning task', b'1', '2024-05-07 12:09:29', '2024-05-07 12:09:29', NULL),
(3, 'Fertilizing', 'Apply fertilizer to promote growth and flowering', b'1', '2024-05-27 10:13:25', '2024-05-27 10:13:25', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `Id` int(11) NOT NULL,
  `name` varchar(255) CHARACTER SET utf8 NOT NULL,
  `email` varchar(255) CHARACTER SET utf8 NOT NULL,
  `password` varchar(255) CHARACTER SET utf8 NOT NULL,
  `is_active` bit(1) NOT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime DEFAULT NULL,
  `deleted_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_polish_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`Id`, `name`, `email`, `password`, `is_active`, `created_at`, `updated_at`, `deleted_at`) VALUES
(1, 'John Doe', 'john@example.com', 'hashed_password', b'1', '2024-05-07 12:09:29', '2024-05-07 12:09:29', NULL),
(2, 'Karolina', 'k.poreba17@gmail.com', '$2y$12$v2ursBGi0hHXXAmcZ3KcsOsYGUWynK.6.PsTXxRiOE.bCmAGWyyN2', b'1', '2024-05-27 09:30:41', '2024-05-27 09:30:41', NULL);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `images`
--
ALTER TABLE `images`
  ADD PRIMARY KEY (`Id`),
  ADD KEY `PlantId` (`PlantId`);

--
-- Indexes for table `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `notes`
--
ALTER TABLE `notes`
  ADD PRIMARY KEY (`Id`),
  ADD KEY `PlantId` (`PlantId`);

--
-- Indexes for table `plantcaretasks`
--
ALTER TABLE `plantcaretasks`
  ADD PRIMARY KEY (`Id`),
  ADD KEY `PlantId` (`PlantId`),
  ADD KEY `TaskTypeId` (`TaskTypeId`);

--
-- Indexes for table `plants`
--
ALTER TABLE `plants`
  ADD PRIMARY KEY (`Id`),
  ADD KEY `UserId` (`UserId`),
  ADD KEY `SpeciesId` (`SpeciesId`);

--
-- Indexes for table `planttags`
--
ALTER TABLE `planttags`
  ADD PRIMARY KEY (`Id`),
  ADD KEY `PlantId` (`PlantId`),
  ADD KEY `TagId` (`TagId`);

--
-- Indexes for table `sessions`
--
ALTER TABLE `sessions`
  ADD PRIMARY KEY (`id`),
  ADD KEY `sessions_user_id_index` (`user_id`),
  ADD KEY `sessions_last_activity_index` (`last_activity`);

--
-- Indexes for table `species`
--
ALTER TABLE `species`
  ADD PRIMARY KEY (`Id`);

--
-- Indexes for table `tags`
--
ALTER TABLE `tags`
  ADD PRIMARY KEY (`Id`);

--
-- Indexes for table `tasktypes`
--
ALTER TABLE `tasktypes`
  ADD PRIMARY KEY (`Id`),
  ADD UNIQUE KEY `Name` (`Name`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`Id`),
  ADD UNIQUE KEY `Email` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `images`
--
ALTER TABLE `images`
  MODIFY `Id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `migrations`
--
ALTER TABLE `migrations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `notes`
--
ALTER TABLE `notes`
  MODIFY `Id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT for table `plantcaretasks`
--
ALTER TABLE `plantcaretasks`
  MODIFY `Id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `plants`
--
ALTER TABLE `plants`
  MODIFY `Id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `planttags`
--
ALTER TABLE `planttags`
  MODIFY `Id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `species`
--
ALTER TABLE `species`
  MODIFY `Id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `tags`
--
ALTER TABLE `tags`
  MODIFY `Id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `tasktypes`
--
ALTER TABLE `tasktypes`
  MODIFY `Id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `Id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `images`
--
ALTER TABLE `images`
  ADD CONSTRAINT `images_ibfk_1` FOREIGN KEY (`PlantId`) REFERENCES `plants` (`Id`);

--
-- Constraints for table `notes`
--
ALTER TABLE `notes`
  ADD CONSTRAINT `notes_ibfk_1` FOREIGN KEY (`PlantId`) REFERENCES `plants` (`Id`);

--
-- Constraints for table `plantcaretasks`
--
ALTER TABLE `plantcaretasks`
  ADD CONSTRAINT `plantcaretasks_ibfk_1` FOREIGN KEY (`PlantId`) REFERENCES `plants` (`Id`),
  ADD CONSTRAINT `plantcaretasks_ibfk_2` FOREIGN KEY (`TaskTypeId`) REFERENCES `tasktypes` (`Id`);

--
-- Constraints for table `plants`
--
ALTER TABLE `plants`
  ADD CONSTRAINT `plants_ibfk_1` FOREIGN KEY (`UserId`) REFERENCES `users` (`Id`),
  ADD CONSTRAINT `plants_ibfk_2` FOREIGN KEY (`SpeciesId`) REFERENCES `species` (`Id`);

--
-- Constraints for table `planttags`
--
ALTER TABLE `planttags`
  ADD CONSTRAINT `planttags_ibfk_1` FOREIGN KEY (`PlantId`) REFERENCES `plants` (`Id`),
  ADD CONSTRAINT `planttags_ibfk_2` FOREIGN KEY (`TagId`) REFERENCES `tags` (`Id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
